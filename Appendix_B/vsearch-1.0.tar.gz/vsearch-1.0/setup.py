from setuptools import setup


setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='Zac',
    author_email='xiezac@163.com',
    url='xiezac.com',
    py_modules=['vsearch']
)
